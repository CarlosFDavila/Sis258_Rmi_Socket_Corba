package sisbanco2;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;


/**
 *
 * @author Laura Veronica Risueño Arancibia<lauri.lro4@gmail.com>
 */
public class ConexiónMongoDB {
    public static void main(String args[]){
       MongoClient client = new MongoClient("localhost", 27017);
       MongoDatabase db = client.getDatabase("facturas");
    }
}
